# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# user:MD5password:Real Name:email:groups,comma,seperated


admin:21232f297a57a5a743894a0e4a801fc3:Administrator:admin@example.com:admin,user
